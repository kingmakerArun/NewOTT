// import 'package:flutter/material.dart';
//
// import 'HomeViewLarge.dart';
// import 'HomeViewSmall.dart';
//
// class mainr extends StatefulWidget {
//   const mainr({super.key});
//
//   @override
//   State<mainr> createState() => _mainrState();
// }
//
// class _mainrState extends State<mainr> {
//   int _currentIndex = 0;
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: LayoutBuilder(
//         builder: (context, constraints)
//         {
//           if(constraints.maxWidth<600)
//             {
//               return HomeViewSmall(_currentIndex,(index){
//                 setState(() {
//                   _currentIndex=index;
//                 });
//               });
//             }
//           else
//             {
//               return HomeViewLarge(_currentIndex,(index){
//                 setState(() {
//                   _currentIndex=index;
//                 });
//               });
//             }
//         },
//
//       ),
//     );
//   }
// }
