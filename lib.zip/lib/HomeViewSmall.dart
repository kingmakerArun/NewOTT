import 'package:flutter/material.dart';
import 'package:newott/splash.dart';
import 'package:responsive_framework/responsive_framework.dart';

class HomeViewSmall extends StatelessWidget {

  HomeViewSmall({super.key});

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;
    final isPortrait = mediaQueryData.orientation == Orientation.portrait;
    final pixelRatio = mediaQueryData.devicePixelRatio;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [

            splash(),

          ],
        ),
      ),
    );


  }
}

// Text(
//   "Hello, this is a text",
//   style: TextStyle(
//     fontSize: isPortrait ? 20 : 16,
//     color: Colors.green[300],
//   ),
// ),
// Add your widgets here to try.

// MaterialApp(
// builder: (context, widget) => ResponsiveWrapper.builder(
// BouncingScrollWrapper.builder(context, widget!),
// defaultScale: true,
// breakpoints: [
// ResponsiveBreakpoint.resize(480, name: MOBILE),
// ResponsiveBreakpoint.autoScale(800, name: TABLET),
// ResponsiveBreakpoint.resize(1000, name: DESKTOP),
// ResponsiveBreakpoint.autoScale(2460, name: '4K'),
// ],
// ),
// home: splash(),
// );
// class MyHomePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     splash();
//   }
// }

// MaterialApp(
// // Wrapping the app with a builder method makes breakpoints
// // accessible throughout the widget tree.
// builder: (context, child) => ResponsiveBreakpoints.builder(
// breakpoints: [
// const Breakpoint(start: 0, end: 450, name: MOBILE),
// const Breakpoint(start: 451, end: 800, name: TABLET),
// const Breakpoint(start: 801, end: 1920, name: DESKTOP),
// const Breakpoint(start: 1921, end: double.infinity, name: '4K'),
// ],
// child: child!,
// ),
// initialRoute: '/',
// onGenerateRoute: (RouteSettings settings) {
// return MaterialPageRoute(builder: (context) {
// return BouncingScrollWrapper.builder(
// context, buildPage(settings.name ?? ''),
// dragWithMouse: true);
// });
// },
// debugShowCheckedModeBanner: false,
// );
// Widget buildPage(String name) {
//   switch (name) {
//     case '/':
//     case splash.name:
//       return splash();
//     case HomeViewSmall.name:
//     // Custom "per-page" breakpoints.
//       return const ResponsiveBreakpoints(breakpoints: [
//         Breakpoint(start: 0, end: 480, name: MOBILE),
//         Breakpoint(start: 481, end: 1200, name: TABLET),
//         Breakpoint(start: 1201, end: double.infinity, name: DESKTOP),
//       ], child: splash());
//     case TypographyPage.name:
//       return HomeViewSmall();
//     default:
//       return const SizedBox.shrink();
//   }
// }


// Column(
// children: [
// Row(
// children: [
// Container(
// height: MediaQuery.of(context).size.height/2,
// width:  MediaQuery.of(context).size.width/2.5,
// color: Colors.cyanAccent,
// ),
// Padding(
// padding: const EdgeInsets.all(8.0),
// child: Container(
// height: MediaQuery.of(context).size.height/2,
// width:  MediaQuery.of(context).size.width/2.5,
// color: Colors.cyanAccent,
// ),
// ),
// ],
// )
//
// ],
// )