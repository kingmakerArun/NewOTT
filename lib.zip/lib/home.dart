import 'package:flutter/material.dart';
import 'package:newott/space.dart';

import 'Search.dart';
import 'descri.dart';
import 'download.dart';
import 'homepage.dart';
import 'login page.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {


  int _index=0;

  final pages=
  [
    HomePage(),
    Search(),
    Download(),
    Space(),

  ];

  void tap(g)
  {
    setState(() {
      _index=g;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black26,
      body:pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        items:  [
          BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.deepOrange),label: "Home",),
          BottomNavigationBarItem(icon: Icon(Icons.search,color: Colors.deepOrange),label: "Search"),
          BottomNavigationBarItem(icon: Icon(Icons.download,color: Colors.deepOrange),label: "Downloads"),
          BottomNavigationBarItem(icon: Icon(Icons.spa,color: Colors.deepOrange),label: "My Spaces"),
        ],
        currentIndex: _index,
        selectedItemColor: Colors.amber[800],
        onTap: tap,
      ),
    );
  }
}

