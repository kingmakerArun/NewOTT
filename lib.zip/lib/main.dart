import 'package:flutter/material.dart';
import 'package:newott/space.dart';
import 'package:newott/splash.dart';
import 'package:newott/MyThemePreferences.dart';
import 'package:responsive_framework/responsive_framework.dart';
import 'HomeViewSmall.dart';
import 'Search.dart';
import 'descri.dart';
import 'download.dart';
import 'home.dart';
import 'homepage.dart';
import 'login page.dart';
import 'mainr.dart';
import 'orientation.dart';
import 'package:newott/ModelTheme.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flex_seed_scheme/flex_seed_scheme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {



    return ChangeNotifierProvider(
        create: (_) => ModelTheme(),
        child: Consumer<ModelTheme>(
        builder: (context, ModelTheme themeNotifier, child) {
      return MaterialApp(
      builder: (context, child) => ResponsiveWrapper.builder(
          BouncingScrollWrapper.builder(context, child!),
          maxWidth: 1200,
          minWidth: 450,
          defaultScale: true,
          breakpoints: [
            const ResponsiveBreakpoint.resize(450, name: MOBILE),
            const ResponsiveBreakpoint.autoScale(800, name: TABLET),
            const ResponsiveBreakpoint.autoScale(1000, name: TABLET),
            const ResponsiveBreakpoint.resize(1200, name: DESKTOP),
            const ResponsiveBreakpoint.autoScale(2460, name: "4K"),
          ],
          background: Container(color: Color(0xFF000000))),
      debugShowCheckedModeBanner: false,
          theme:
          themeNotifier.isDark
              ?
          ThemeData(
            useMaterial3: true,
                  colorScheme:
                  ColorScheme.fromSeed(brightness: Brightness.dark, seedColor: Colors.green),
                  textTheme:
                  GoogleFonts.montserratTextTheme(Theme.of(context).textTheme),
                  primaryTextTheme: GoogleFonts.montserratTextTheme(Theme.of(context).textTheme).apply(bodyColor: Colors.white),
          )
              : ThemeData(
              useMaterial3: true,
                      colorScheme:
                      ColorScheme.fromSeed(brightness: Brightness.light,seedColor: Colors.red),
                      textTheme:
                      GoogleFonts.montserratTextTheme(Theme.of(context).textTheme).apply(bodyColor: Colors.black),
                      primaryTextTheme: GoogleFonts.montserratTextTheme(Theme.of(context).textTheme).apply(
                          bodyColor: Colors.black),
          ),
      home: Space(),
    );
        }),
    );
  }
}




// themeNotifier.isDark
//     ?
// ThemeData(
// brightness: Brightness.dark,
// )
//     : ThemeData(
//     colorScheme: ColorScheme.fromSwatch(
//       primarySwatch: Colors.blueGrey,
//     ),
//     brightness: Brightness.light,
//     primaryColor: Colors.white,
//     primarySwatch: Colors.green,
//   useMaterial3: true,
//   textTheme: TextTheme(
//     headline6: TextStyle(fontSize: 20.0,
//         fontWeight: FontWeight.bold),
//     bodyText2: TextStyle(fontSize: 16.0),
//     bodyText1: TextStyle(fontSize: 16.0, color: Colors.black),
//   ),
// ),


