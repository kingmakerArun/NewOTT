import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:newott/MyThemePreferences.dart';
import 'package:newott/ModelTheme.dart';
import 'package:provider/provider.dart';

import 'home.dart';
import 'homepage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

TextEditingController name = TextEditingController();
TextEditingController pwd = TextEditingController();
final _key = GlobalKey<FormState>();

  bool _show=false;

  a()
  {
    setState(() {
      _show = name.text.isNotEmpty && pwd.text.isNotEmpty == true;
    });
  }
  @override
  Widget build(BuildContext context) {
    return
      Consumer<ModelTheme>(
      builder: (context, ModelTheme themeNotifier, child) {
        return
          Scaffold(
          appBar: AppBar(
            leading: Padding(
              padding: EdgeInsets.all(2.0),
              child: Image.network(
                  "https://i.pinimg.com/474x/64/43/33/6443339172261f5ec62aebb9277f940f.jpg"),
            ),
            title: Center(child: Text("Login Page",
              style: TextStyle(fontSize: 15, color: Colors.lightBlue),)),
            actions: [
              Icon(Icons.search),
            ],
          ),

          body:
          Form(
            key: _key,
            autovalidateMode: AutovalidateMode.always,
            child: Column(
              children: [
                // SizedBox(height: 10,),
                Padding(
                  padding: EdgeInsets.all(30.0),
                  child: TextFormField(
                    controller: name,
                    decoration: InputDecoration(
                      hintText: 'Enter the user name',
                      hintStyle: TextStyle(color: Colors.green, fontSize: 12),
                      border: OutlineInputBorder(),
                    ),
                    validator: (input) {
                      if (input == null || input.isEmpty || !RegExp(
                          r"^[a-zA-Z]").hasMatch(input)) {
                        return 'Please enter the User name';
                      }
                    },
                    onChanged: (input) {
                      a();
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(30.0),
                  child: TextFormField(
                    controller: pwd,
                    decoration: InputDecoration(
                      hintText: 'Enter the Password',
                      hintStyle: TextStyle(color: Colors.green, fontSize: 12),
                      border: OutlineInputBorder(),
                    ),
                    validator: (input) {
                      if (input == null || input.isEmpty || !RegExp(
                          r"^[a-zA-Z0-9]").hasMatch(input)) {
                        return 'Please enter the Password';
                      }
                    },
                    onChanged: (input) {
                      a();
                    },
                  ),
                ),
                // SizedBox(height: 10,),
                Visibility(
                  visible: _show,
                  child: ElevatedButton(onPressed: () {
                    setState(() {
                      Navigator.
                      push(context,
                        MaterialPageRoute(builder: (context) =>
                            Home()),);
                    });
                  }, child: Text("Login")),
                ),
                SizedBox(height: 30,),
                Container(
                  // height: 110,
                  width: 200,
                  child: Column(
                    children: [
                      Image.network("https://media.licdn.com/dms/image/D4D22AQGEfSCpe7zwrQ/feedshare-shrink_2048_1536/0/1685110279536?e=2147483647&v=beta&t=VzxRnqv5lD0FomGHt_HAuYWTE6RKWySz-MX2o5Lf1yM"),
                      SizedBox(height: 10,),
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.center,
                      //     children: [
                      //       IconButton(
                      //           icon: Icon(themeNotifier.isDark
                      //               ? Icons.wb_sunny
                      //               : Icons.nightlight_round),
                      //           onPressed: () {
                      //             themeNotifier.isDark
                      //                 ? themeNotifier.isDark = false
                      //                 : themeNotifier.isDark = true;
                      //           },),
                      //       ElevatedButton(
                      //         onPressed: () {
                      //           themeNotifier.isDark
                      //               ? themeNotifier.isDark = false
                      //               : themeNotifier.isDark = true;
                      //         },
                      //         child: Text('Apps theme'),
                      //       ),
                      //     ],
                      //   ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      });
  }
}
